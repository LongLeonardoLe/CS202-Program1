#include "node.h"
#include "line.h"

int main()
{ 
    graph g;
    g.generate();
    g.display();

    return 0;
}

